package application;

import java.awt.EventQueue;
import java.awt.List;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.stream.Collectors;

import javax.swing.text.html.parser.Element;

import javafx.scene.control.TreeItem.TreeModificationEvent;
import javafx.application.Application;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.ListView;
import javafx.scene.control.Pagination;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.cell.ComboBoxListCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritablePixelFormat;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.web.HTMLEditor;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.scene.control.Label;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.Desktop;

public class Main extends Application implements EventHandler<ActionEvent> {

	static ArrayList<Product> productlist = new ArrayList<Product>();
	
	ArrayList<String> productnamesP3 = new ArrayList<String>();
	
	ObservableList<String> data2 = FXCollections.observableArrayList(productnamesP3);

	public static final ObservableList names = FXCollections.observableArrayList();
	

	ArrayList<TreeItem> categories = new ArrayList<TreeItem>();
	TreeView treeView;
	ListView listView;
	ListView listViewP3;
	private TableView<Product> table = new TableView<Product>();

	Scene scene3;
	Scene scene2;
	Scene scene1;
	Button addButton;
	TextField nameField, categoryField, priceField;
	DatePicker datePicker;
	ProgressBar progress;
	public int id = 0;
	public String name, category, price, date;
	Label errormessage = new Label("");

	ColorPicker colorPicker = new ColorPicker();
	Button applyButton = new Button();

	VBox vbox = new VBox();

	VBox vbox2 = new VBox();
	Double pb = 0.0;

	protected int i = 0;

	private final Desktop desktop = Desktop.getDesktop();

	public void start(Stage stage) {

		CreateList();
		CreateTable();
		CreateTree();

		// -----------Page 1--------------------

		// Setting up Page 1
		Group root1 = new Group();
		scene1 = new Scene(root1, 700, 640);

		Label label1 = new Label("Product Viewer");
		label1.setAlignment(Pos.TOP_CENTER);
		label1.setFont(new Font("Arial", 30));
		label1.setTextFill(Color.web("#FF0000"));

		label1.setLayoutY(3);
		label1.setLayoutX(250);

		// Buttons that allow scene changes
		Button buttonP2 = new Button("Product Creator");
		buttonP2.setLayoutX(325);
		buttonP2.setLayoutY(570);
		buttonP2.setOnAction(e -> stage.setScene(scene2));

		Button buttonP3 = new Button("HTML Editor");
		buttonP3.setLayoutX(325);
		buttonP3.setLayoutY(600);
		buttonP3.setOnAction(e -> stage.setScene(scene3));

		// Setting the layout of Page 1
		VBox v1 = new VBox();
		HBox h1 = new HBox();
		root1.getChildren().add(h1);
		root1.getChildren().add(v1);

		// Adding the elements of Page 1
		h1.getChildren().add(table);
		h1.getChildren().add(treeView);
		h1.getChildren().add(listView);
		root1.getChildren().add(buttonP2);
		root1.getChildren().add(buttonP3);

		v1.setAlignment(Pos.CENTER);
		h1.setLayoutY(50);
		root1.getChildren().add(label1);

		// -----------Page 2--------------------

		// Setting up the scene of page 2
		Group root2 = new Group();
		scene2 = new Scene(root2, 600, 450);

		// Name fields for user input
		nameField = new TextField();
		nameField.setMaxWidth(200);
		Text nameText = new Text(" Product name:  ");
		nameText.setFill(Color.web("#0000FF"));

		categoryField = new TextField();
		categoryField.setMaxWidth(200);
		Text categoryText = new Text(" Category name:");
		categoryText.setFill(Color.web("#0000FF"));

		priceField = new TextField();
		priceField.setMaxWidth(200);
		Text priceText = new Text(" Product price:   ");
		priceText.setFill(Color.web("#0000FF"));
		progress = new ProgressBar();
		progress.setProgress(0.0);

		// Date Picker**
		datePicker = new DatePicker();
		Text dateText = new Text(" Submission date:    ");
		dateText.setFill(Color.web("#0000FF"));

		// Color Picker**
		colorPicker = new ColorPicker();
		Text applyText = new Text("Change this page's background color:");
		applyButton = new Button("Apply Color");
		applyButton.setOnAction(e -> handle2(e));

		Label Title = new Label("Product Creator");
		Title.setFont(new Font("Arial", 30));
		Title.setTextFill(Color.web("#FF0000"));

		Button button2 = new Button("Product Viewer");
		button2.setOnAction(e -> stage.setScene(scene1));

		Button button3 = new Button("HTML Editor");
		button3.setOnAction(e -> stage.setScene(scene3));

		addButton = new Button("Add Product");
		addButton.setOnAction(this);

		errormessage.setText("");
		errormessage.setFont(new Font("Arial", 30));
		errormessage.setTextFill(Color.web("#FF0000"));
		errormessage.setAlignment(Pos.BASELINE_CENTER);

		// Setting the layout of Page 2
		HBox hboxTitle = new HBox(5);
		HBox hboxName = new HBox(5);
		HBox hboxCategory = new HBox(5);
		HBox hboxPrice = new HBox(5);
		HBox hboxDate = new HBox(5);

		HBox hboxError = new HBox();
		HBox hboxPage = new HBox();
		HBox hboxColor = new HBox(5);

		// Adding the elements of Page 2
		hboxColor.getChildren().addAll(applyText, colorPicker, applyButton);
		hboxColor.setAlignment(Pos.BOTTOM_CENTER);
		hboxTitle.setAlignment(Pos.BASELINE_CENTER);

		hboxTitle.getChildren().addAll(Title);
		hboxName.getChildren().addAll(nameText, nameField);
		hboxCategory.getChildren().addAll(categoryText, categoryField);
		hboxPrice.getChildren().addAll(priceText, priceField);
		hboxDate.getChildren().addAll(dateText, datePicker);
		hboxName.setAlignment(Pos.BASELINE_CENTER);
		hboxPrice.setAlignment(Pos.BASELINE_CENTER);
		hboxDate.setAlignment(Pos.BASELINE_CENTER);
		hboxCategory.setAlignment(Pos.BASELINE_CENTER);
		hboxError.getChildren().add(errormessage);
		hboxError.setAlignment(Pos.BASELINE_CENTER);
		hboxPage.getChildren().add(button2);

		hboxPage.setAlignment(Pos.BOTTOM_CENTER);
		vbox = new VBox(12, hboxTitle, hboxName, hboxCategory, hboxPrice, hboxDate, addButton);
		vbox.setPrefSize(600, 450);

		vbox.getChildren().add(progress);
		vbox.getChildren().add(hboxError);

		vbox.getChildren().add(hboxColor);
		vbox.getChildren().add(hboxPage);
		vbox.getChildren().add(button3);
		vbox.setAlignment(Pos.BASELINE_CENTER);
		root2.getChildren().add(vbox);

		// -----------Page 3--------------------

		// Setting up Page 3
		scene3 = new Scene(new Group());

		// Setting the layout of Page 3
		vbox2.setPadding(new Insets(16, 16, 16, 16));
		vbox2.setSpacing(5);
		vbox2.setAlignment(Pos.BOTTOM_LEFT);
		HBox hList = new HBox();
		hList.setPrefHeight(100);
		hList.setAlignment(Pos.CENTER);

		CreateListP3();

		final HTMLEditor htmlEditor = new HTMLEditor();
		htmlEditor.setPrefWidth(450);
		htmlEditor.setPrefHeight(245);

		final TextArea htmlCode = new TextArea();
		htmlCode.setWrapText(true);
		
		//ListView EventHandler on Item Click
		listViewP3.setOnMouseClicked(new CustomEventHandler(i) {
			@Override
			public void handle(MouseEvent event) {
				try {
					String PName = "";
					String PCategory = "";
					String PDate = "";
					Double PPrice = 0.0;
					String PData = "";
					System.out.println("clicked on " + listViewP3.getSelectionModel().getSelectedItem());
					String names = (String) listViewP3.getSelectionModel().getSelectedItem();
					int i = 0;
					for (Product p : productlist) {
						if (p.getName() == names) {
							i = productlist.indexOf(p);
						}
					}
					Product p = productlist.get(i);
					PName = p.getName();
					PCategory = p.getCategory();
					PDate = p.getDate();
					PPrice = p.getPrice();
					PData = p.getHTML();
					String data = "<html dir=\"ltr\"><head></head><body contenteditable=\"true\">"
							+ "<h1><span style=\"font-size: xx-large;\">" + PName + "</span></h1>"
							+ "<p><span style=\"font-family: &quot;&quot;;\">" + PCategory + "</span></p>"
							+ "<p><span style=\"font-family: &quot;&quot;;\">" + PDate + "</span></p>"
							+ "<p><span style=\"font-family: &quot;&quot;;\">" + PPrice + "$" + "</span></p>";

					htmlEditor.setHtmlText(PData);
					p.setHTML(htmlEditor.getHtmlText());
					setI(i);
				} 
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}

			}
		});

		hList.getChildren().add(listViewP3);

		//Explain ScrollPane
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.getStyleClass().add("noborder-scroll-pane");
		scrollPane.setContent(htmlCode);
		scrollPane.setPrefWidth(500);
		scrollPane.setPrefHeight(80);
		
		Button showHTMLButton = new Button("Produce HTML Code");
		vbox2.setAlignment(Pos.CENTER);
		showHTMLButton.setOnAction((ActionEvent arg0) -> {
			htmlCode.setText(htmlEditor.getHtmlText()); //The HTML Editor produces HTML code
		});

		final WebView browser = new WebView();
		final WebEngine webEngine = browser.getEngine();

		ScrollPane scrollPaneWEB = new ScrollPane();
		scrollPaneWEB.getStyleClass().add("noborder-scroll-pane");
		scrollPaneWEB.setContent(browser);
		scrollPaneWEB.setPrefWidth(500);
		scrollPaneWEB.setPrefHeight(180);
		
		ImageView imgView = new ImageView();
		imgView.setFitWidth(500);
		imgView.setFitHeight(200);
		
		HBox hboximgPane = new HBox();
		hboximgPane.setPrefWidth(800);
		hboximgPane.setPrefHeight(200);
		hboximgPane.getChildren().addAll(scrollPane, imgView);

		Button showHTMLButtonWEB = new Button("Load Content in Browser");

		vbox2.setAlignment(Pos.CENTER);
		
		//WebEngine Reads HTML Code
		showHTMLButtonWEB.setOnAction((ActionEvent arg0) -> {
			try {
				Product p = productlist.get(CustomEventHandler.getI());
				p.setHTML(htmlEditor.getHtmlText());
				webEngine.loadContent(htmlEditor.getHtmlText());
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
			}
		});

		final FileChooser fileChooser = new FileChooser();
		final Button upload = new Button("Upload");

		//Explain FileChooser
		upload.setOnAction((final ActionEvent e) -> {
			configureFileChooser(fileChooser);
			File file = fileChooser.showOpenDialog(stage);
			if (file != null) {
				openFile(file, imgView);
			}
		});

		Button buttonP1 = new Button("Product Viewer");
		buttonP1.setLayoutX(325);
		buttonP1.setLayoutY(600);
		buttonP1.setOnAction(e -> stage.setScene(scene1));
		
        Pagination pagination = new Pagination(28, 0);
        pagination.getStyleClass().add(Pagination.STYLE_CLASS_BULLET); //set style of the numeric indices to bullets
        pagination.setPageFactory((Integer pageIndex) -> {
            if (pageIndex >= productlist.size()) {
                return null;
            } else {
                return createPage(pageIndex);
            }
        });
        
		Button buttonPagBack = new Button("HTML Editor");
		buttonPagBack.setLayoutX(325);
		buttonPagBack.setLayoutY(600);
		buttonPagBack.setOnAction(e -> stage.setScene(scene3));
       
        //Explain AnchorPane
        AnchorPane anchor = new AnchorPane();
        AnchorPane.setTopAnchor(pagination, 10.0);
        AnchorPane.setRightAnchor(pagination, 10.0);
        AnchorPane.setBottomAnchor(pagination, 10.0);
        AnchorPane.setLeftAnchor(pagination, 10.0);
        //Position the Button
        AnchorPane.setTopAnchor(buttonPagBack, 340.0);
        AnchorPane.setRightAnchor(buttonPagBack, 50.0);
        AnchorPane.setBottomAnchor(buttonPagBack, 15.0);
        AnchorPane.setLeftAnchor(buttonPagBack, 565.0);
        anchor.getStylesheets().add(Main.class.getResource("pagStyle.css").toExternalForm());  //get the Stylesheet
        anchor.getChildren().addAll(pagination, buttonPagBack);
		
		Scene pagscn = new Scene(anchor, 700, 400);
		
		Button pagbtn = new Button("Pagination");
		pagbtn.setLayoutX(325);
		pagbtn.setLayoutY(620);
		pagbtn.setOnAction(e -> stage.setScene(pagscn));

		HBox hhtmlWeb = new HBox();

		hhtmlWeb.getChildren().addAll(htmlEditor, scrollPaneWEB);
		vbox2.getChildren().addAll(hhtmlWeb, showHTMLButton, hboximgPane, showHTMLButtonWEB, hList, buttonP1, upload, pagbtn);

		scene3.setRoot(vbox2);

		// End of Page 3

		// Change Scenes
		stage.setTitle("JavaFX GUI Demo");
		stage.setScene(scene1);
		stage.setResizable(false);
		stage.sizeToScene();
		stage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}

	public void CreateTable() {

		table.setPrefSize(360, 500);
		table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

		// ObservableList: A list that enables listeners to track changes when they
		// occur.
		ObservableList<Product> data = FXCollections.observableArrayList(productlist);

		table.setEditable(true);

		TableColumn<Product, Double> PriceCol = new TableColumn<>("Price");
		PriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

		TableColumn<Product, String> NameCol = new TableColumn<>("Name");
		NameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

		TableColumn<Product, String> CatCol = new TableColumn<>("Category");
		CatCol.setCellValueFactory(new PropertyValueFactory<>("category"));

		TableColumn<Product, String> DateCol = new TableColumn<>("Date");
		DateCol.setCellValueFactory(new PropertyValueFactory<>("date"));

		table.setItems(data);
		table.getColumns().setAll(NameCol, CatCol, PriceCol, DateCol);

	}

	public void CreateList() {

		// Creating the List View
		listView = new ListView();
		listView.setPrefSize(200, 250);
		listView.setEditable(true);

		// Populating an ArrayList with the product names.
		ArrayList<String> productnames = new ArrayList<String>();
		for (int i = 0; i < productlist.size(); i++) {
			productnames.add(productlist.get(i).getName());
		}

		// Clearing the list to avoid duplicates
		names.clear();

		// Adding the product names to the names list
		names.addAll(productnames);

		// Adding the names to the List View
		listView.setItems(names);
	}

	public void CreateTree() {
		// Creating the Tree View

		treeView = new TreeView();
		treeView.setPrefSize(180, 45);

	}

	public void UpdateTree() {
		TreeItem rootItem = new TreeItem("Products");
		// Clearing the tree upon update to avoid duplicates
		rootItem.getChildren().clear();
		categories.clear();

		// The root of the tree is the Tree Item rootItem
		treeView.setRoot(rootItem);

		// Array Lists that will each respectively hold the category and product names
		ArrayList<String> categorynames = new ArrayList<String>();
		ArrayList<String> productnames = new ArrayList<String>();
		for (int i = 0; i < productlist.size(); i++) {

			categorynames.add(productlist.get(i).getCategory());

		}

		// Eliminating category duplicates
		ArrayList<String> newcategorynames = new ArrayList<String>();
		newcategorynames = (ArrayList<String>) categorynames.stream().distinct().collect(Collectors.toList());
		for (int i = 0; i < newcategorynames.size(); i++) {
			TreeItem newcat = new TreeItem(newcategorynames.get(i));
			categories.add(newcat);

		}

		// The main root of the tree has as children the categories.
		// Each category is a node which has as children the products.
		// We go through each product in the product list, and associate each product to
		// its corresponding category
		// We create a tree item for every product and add it to its category node.
		for (int i = 0; i < productlist.size(); i++) {

			for (int k = 0; k < categories.size(); k++) {
				if (productlist.get(i).getCategory().equals(categories.get(k).getValue().toString())) {
					TreeItem newproduct = new TreeItem(productlist.get(i).getName());
					categories.get(k).getChildren().add(newproduct);
				}
			}

		}

		// Adding all categories nodes as children of the main root
		rootItem.getChildren().addAll(categories);

	}

	public void CreateListP3() {
		listViewP3 = new ListView(names);
		listViewP3.setPrefSize(200, 250);
		listViewP3.setEditable(true);

		listViewP3.setPrefSize(180, 45);
		

		for (int i = 0; i < productlist.size(); i++) {
			productnamesP3.add(productlist.get(i).getName());
		}
		names.clear();
		names.addAll(productnamesP3);
		listViewP3.setItems(names);
	}

	public void AddProduct(String name, String category, double price, String date, String html) {

		// Adding a progress bar
		pb += 0.10F;
		progress.setProgress(pb);

		// Instantiating a new product object
		Product product1 = new Product(name, category, price, date, html);

		// Putting the new product in a product list that will be accessed by the tree,
		// table and list.
		productlist.add(product1);

		// Updating the List, Table and Tree
		CreateList();
		CreateTable();
		UpdateTree();

	}

	public void handle(ActionEvent event) {

		boolean PriceInvalid = false;
		try {
			double value = Double.parseDouble(priceField.getText());

		} catch (Exception e) {

			PriceInvalid = true;
		}
		if (PriceInvalid == false && event.getSource() == addButton && nameField.getText() != null
				&& categoryField.getText() != null && priceField.getText() != null && datePicker.getValue() != null) {
			name = nameField.getText();
			category = categoryField.getText();
			price = priceField.getText();
			date = datePicker.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

			nameField.setText("");
			categoryField.setText("");
			priceField.setText("");
			datePicker.setValue(null);

			String html = "<html dir=\"ltr\"><head></head><body contenteditable=\"true\">"
					+ "<h1><span style=\"font-size: xx-large;\">" + name + "</span></h1>"
					+ "<p><span style=\"font-family: &quot;&quot;;\">" + category + "</span></p>"
					+ "<p><span style=\"font-family: &quot;&quot;;\">" + date + "</span></p>"
					+ "<p><span style=\"font-family: &quot;&quot;;\">" + price + "$" + "</span></p>" + "</body></html>";

			AddProduct(name, category, Double.parseDouble(price), date, html);

			errormessage.setText("");
		} else {
			errormessage.setText("Invalid Information. Please try again.");
			errormessage.setFont(new Font("Arial", 20));
			errormessage.setTextFill(Color.web("#FF0000"));

		}
	}

	public void handle2(ActionEvent event) {

		if (event.getSource() == applyButton) {

			vbox.setBackground(new Background(new BackgroundFill(colorPicker.getValue(), null, null)));

		}
	}

	public static void configureFileChooser(final FileChooser fileChooser) {
		fileChooser.setTitle("View Pictures");
		fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
		fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("All Images", "*.*"),
				new FileChooser.ExtensionFilter("JPG", "*.jpg"), new FileChooser.ExtensionFilter("PNG", "*.png"));
	}

	public void openFile(File file, ImageView imgView) {
		EventQueue.invokeLater(() -> {
			try {
				//desktop.open(file);
				String FilePath = file.getAbsolutePath();
				Image img = new Image(file.toURI().toString());
				int width = (int) img.getWidth();
				int height = (int) img.getHeight();
				PixelReader reader = img.getPixelReader();
				byte[] buffer = new byte[width * height * 4];
				File trgtFile = new File("img.png");

				System.out.println(FilePath);

				FileInputStream fis = new FileInputStream(file);
				FileOutputStream fos = new FileOutputStream(trgtFile);
				
				

				int len;
				while ((len = fis.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}
				
				imgView.setImage(img);

				fis.close();
				fos.close();

				/*
				 * WritablePixelFormat<ByteBuffer> format =
				 * WritablePixelFormat.getByteBgraInstance(); reader.getPixels(0, 0, width,
				 * height, format, buffer, 0, width * 4); try { BufferedOutputStream out = new
				 * BufferedOutputStream(new FileOutputStream("test.png")); for(int count = 0;
				 * count < buffer.length; count += 4) { out.write(buffer[count + 2]);
				 * out.write(buffer[count + 1]); out.write(buffer[count]);
				 * out.write(buffer[count + 3]); } out.flush(); out.close(); } catch(IOException
				 * e) { e.printStackTrace(); }
				 */

			} catch (IOException ex) {
				Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
			}
		});
	}
	
    public int itemsPerPage() {
        return 4;
    }
	
    
	public VBox createPage(int pageIndex) {
        VBox box = new VBox(5);
        int page = pageIndex * itemsPerPage();
        try {
            for (int i = page; i < page + itemsPerPage(); i++) {
                Label text = new Label(productlist.get(i).getName());
                Label price = new Label(Double.toString(productlist.get(i).getPrice()) + "$");
                text.setFont(new Font("Cambria", 40));
                text.setWrapText(true);
                price.setFont(new Font("Courier New", 20));
                price.setWrapText(true);
                box.getChildren().addAll(text, price);
            }
        } catch (Exception e) {
        	System.out.println("No More Items");
        }

        return box;
    }
}
