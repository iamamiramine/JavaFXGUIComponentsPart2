package application;



public class Product {
    private String Name;
    private String Category;
    private double Price; 
    private String Date;
    private String HTML;

    Product(String Name, String Category, Double Price, String Date, String HTML) {
        this.Name = new String(Name);
        this.Category = new String(Category);
        this.Price = new Double(Price);
        this.Date = new String(Date);
        this.HTML = new String(HTML);
    }
 
    public String getName() {
        return Name;
    }
    public void setName(String Name) {
        this.Name = Name;
    }
        
    public String getCategory() {
        return Category;
    }
    public void setCategory(String Category) {
        this.Category = Category;
    }
    
    public double getPrice() {
        return Price;
    }
    public void setPrice(double Price) {
        this.Price = Price;
    }
    public String getDate() {
    	return Date;
    }
    public void setDate(String Date) {
    	this.Date = Date;
    }

	public String getHTML() {
		return HTML;
	}

	public void setHTML(String hTML) {
		HTML = hTML;
	}
  
}