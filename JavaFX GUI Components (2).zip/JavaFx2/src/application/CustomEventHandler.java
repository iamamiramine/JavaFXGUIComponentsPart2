package application;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class CustomEventHandler implements EventHandler<MouseEvent> {
	
	  private static int i;

	    public CustomEventHandler(int i) {
	        this.i = i;
	    }
	    
	    public void handle(MouseEvent event) {
	        System.out.println(getI());
	    }

	    public static int getI() {
	        return i;
	    }

		public void setI(int i) {
			this.i = i;
		}
	   
}
